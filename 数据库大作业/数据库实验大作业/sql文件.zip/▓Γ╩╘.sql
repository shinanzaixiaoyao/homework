use hotel_management_system;

select *
from customer c ;

select *
from book_info bi ;


select *
from hotel h ;

select *
from pay_info pi2 ;

select *
from room r ;

select *
from v_ht vh ;

select *
from v_os vo ;

select *
from v_rm vr ;

select *
from room r 
where r.rf = '1';

delete from book_info 
where bid = 'book010';

 
